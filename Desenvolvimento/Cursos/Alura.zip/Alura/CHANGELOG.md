# Changelog

> **NOTA:** Este changelog está em construção e todas as alterações serão corrigidas logo e autalizadas com frequência, Modelo para Projeto Alura/ONE

## [Data - Versão]
- Descrição da mudança [#Em breve será listada aqui](Em construção) => DATA CRIAÇÃO CHANGELOG.md: 18/02/2025 -> Criado por Rafael Martiniano | Usado GIT/GITHUB

## 2025-02-18
- Update README.md (#9b999c1)
- Create CODE_OF_CONDUCT.md (#f10dac3)
- Update README.md (#530cbde)
- Update README.md (#3547516)
- Atualizar o README.md (#73b4857)

## 2025-02-17
- Atualizar o README.md (#6768e51)
- Atualizar o README.md (#8441b75)

## 2025-02-16
- Update README.md (#d67bc7e)
- Update README.md (#b5e5475)
- Update README.md (#9eeb8ee)
- Update README.md (#a162e4b)
- Update README.md (#674f8cd)
- Update README.md (#f44a830)
- Update README.md (#b3c98a5)
- Update README.md (#9b2770d)
- Update README.md (#9b404a8)
- Update README.md (#12bcfe9)
- Update README.md (#3cb1fc1)
- Update README.md (#fd347ca)

## 2025-02-12
- Update README.md (#b801b64)
- Update README.md (#ff24712)
- 1C - Primeiro Commit - Projeto Atual - Amigo Secreto (#d831043)

## 2025-02-10
- 1R - Versão - Criação README.md (#bd32748)
- Initial commit (#6a34c01)

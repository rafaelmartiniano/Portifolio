// ** Criando as Variaveis ** //

let primeiroNumero= 1;
let primeiraString = '1';
let segundoNumero = 30;
let segundaString ='30';
let terceiroNumero = 10;
let terceiraString = '10';

//------------------- Separador --------------------//
alert('Iniciando programa, clique em ok para continuar!')
alert('O programa fará a analise, se estiver correto, conseguirá ver as instruções, mas se estiver errado, corrija o erro de sintaxe')
alert('Clique em ok para iniciar!')

// **Criando condição de comparação para as variaveis**//

if (primeiroNumero == primeiraString) {
  console.log("As variáveis primeiroNumero e primeiraString são de valores iguais, mas com tipos de variaveis diferentes");
} else {
  console.log('As variáveis primeiroNumero e primeiraString são de valores diferentes não tem o mesmo valor');
}

if (segundoNumero == segundaString) {
  console.log('As variáveis segundoNumero e segundaString são de valores iguais, mas com tipos de variaveis diferentes');
} else {
  console.log('As variáveis segundoNumero e segundaString são de valores diferentes não tem o mesmo valor');
}

if (terceiroNumero == terceiraString) {
  console.log('As variáveis terceiroNumero e  terceiraString são de valores iguais, mas com tipos de variaveis diferentes');
} else {
  console.log('As variáveis terceiroNumero e terceiraString são de valores diferentes não tem o mesmo valor');
}

alert('Fim do programa, veja o resultado!');
//------------------- Separador --------------------//

// ** Fim da Condição e do programa ** //